-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carpooling
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ride_offers`
--

DROP TABLE IF EXISTS `ride_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ride_offers` (
  `RideOfferID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `FromAddress` varchar(45) NOT NULL,
  `FromAddressLatitude` float NOT NULL,
  `FromAddressLongitude` float NOT NULL,
  `ToAddress` varchar(45) NOT NULL,
  `ToAddressLatitude` float NOT NULL,
  `ToAddressLongitude` float NOT NULL,
  `FromDateTime` datetime NOT NULL,
  `IsRoundTrip` tinyint NOT NULL DEFAULT '0',
  `ToDateTime` datetime DEFAULT NULL,
  `Comments` varchar(200) DEFAULT NULL,
  `PricePerPerson` int NOT NULL,
  `NumberOfSeats` int NOT NULL,
  `MaxLuggage` varchar(45) DEFAULT NULL,
  `AgreeTermConditions` tinyint NOT NULL DEFAULT '1',
  `PublishRide` tinyint NOT NULL DEFAULT '1',
  `CreatedDate` datetime(6) NOT NULL,
  `IsDeleted` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`RideOfferID`),
  KEY `riderOffers_UserId_idx` (`UserID`),
  CONSTRAINT `rideoffer_users` FOREIGN KEY (`UserID`) REFERENCES `appusers` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ride_offers`
--

LOCK TABLES `ride_offers` WRITE;
/*!40000 ALTER TABLE `ride_offers` DISABLE KEYS */;
INSERT INTO `ride_offers` VALUES (1,1,'Mumbai',19.0761,72.8774,'Delhi',28.6448,77.2167,'2022-11-25 20:53:17',0,NULL,'Ride offer',200,3,'20KG',1,1,'2022-11-16 15:12:37.000000',0),(2,2,'Mumbai',19.0761,72.8774,'Delhi',28.6448,77.2167,'2022-12-25 18:00:17',0,NULL,'Ride offer 2',200,3,'25KG',1,1,'2022-11-16 15:13:06.000000',0),(3,1,'Mumbai',19.0761,72.8774,'Delhi',28.6448,77.2167,'2022-12-20 09:53:17',0,NULL,'Ride offer3',200,3,'40KG',1,1,'2022-11-16 15:14:28.000000',0),(4,1,'Mumbai',19.0761,72.8774,'Delhi',28.6448,77.2167,'2022-11-30 11:00:17',0,NULL,'Ride offer',200,3,'20KG',1,1,'2022-11-16 15:15:24.000000',0);
/*!40000 ALTER TABLE `ride_offers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-16 15:59:35
