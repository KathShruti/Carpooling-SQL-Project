-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carpooling
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `user_ratings`
--

DROP TABLE IF EXISTS `user_ratings`;
/*!50001 DROP VIEW IF EXISTS `user_ratings`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user_ratings` AS SELECT 
 1 AS `RatedToUserID`,
 1 AS `UserRating`,
 1 AS `FirstName`,
 1 AS `LastName`,
 1 AS `Email`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `user_ratings`
--

/*!50001 DROP VIEW IF EXISTS `user_ratings`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user_ratings` AS select `ride_ratings`.`RatedToUserID` AS `RatedToUserID`,round(avg(cast(`ride_ratings`.`RatingReceived` as float)),1) AS `UserRating`,`appusers`.`FirstName` AS `FirstName`,`appusers`.`LastName` AS `LastName`,`appusers`.`Email` AS `Email` from (`ride_ratings` join `appusers` on((`ride_ratings`.`RatedToUserID` = `appusers`.`UserID`))) group by `ride_ratings`.`RatedToUserID`,`appusers`.`FirstName`,`appusers`.`LastName`,`appusers`.`Email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'carpooling'
--

--
-- Dumping routines for database 'carpooling'
--
/*!50003 DROP FUNCTION IF EXISTS `GetUserRating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `GetUserRating`(user_Id int) RETURNS int
BEGIN
DECLARE user_rating int DEFAULT 0;
SELECT RatingReceived INTO user_rating FROM ride_ratings WHERE
RatedToUserID = user_Id LIMIT 1;
RETURN user_rating;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UserRatingsGivenTo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UserRatingsGivenTo`(RatedByUserID int)
BEGIN
declare rate5 float;
declare rate4 float;
declare rate3 float;
declare rate2 float;
declare rate1 float;
declare totalRateCount float;
select rate5 = COUNT(RatingReceived) from ride_ratings WHERE RatingReceived = 5 and RatedByUserId =
RatedByUserID;

select rate4 = COUNT(RatingReceived) from ride_ratings WHERE RatingReceived = 4 and RatedByUserId =
RatedByUserID;
select rate3 = COUNT(RatingReceived) from ride_ratings WHERE RatingReceived = 3 and RatedByUserId =
RatedByUserID;
select rate2 = COUNT(RatingReceived) from ride_ratings WHERE RatingReceived = 2 and RatedByUserId =
RatedByUserID;
select rate1 = COUNT(RatingReceived) from ride_ratings WHERE RatingReceived = 1 and RatedByUserId =
RatedByUserID;
Select totalRateCount = COUNT(RatingReceived) from ride_ratings WHERE RatedByUserId = RatedByUserID;
IF(totalRateCount = 0) then
select cast(0 as float) AS RatingFive, cast(0 as float) AS RatingFour, cast(0 as float) AS
RatingThree,
cast(0 as float) AS RatingTwo, cast(0 as float) AS RatingOne;
ELSE
select ROUND(rate5/totalRateCount * 100, 0) AS RatingFive, ROUND(rate4/totalRateCount *
100, 0) AS RatingFour, ROUND(rate3/totalRateCount * 100, 0) AS RatingThree,
ROUND(rate2/totalRateCount * 100, 0) AS RatingTwo, ROUND(rate1/totalRateCount * 100, 0)
AS RatingOne;
 end if;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-16 15:59:38
